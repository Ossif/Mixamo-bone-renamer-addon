import bpy

bl_info = {
    "name": "Mixamo Bone Renamer Addon",
    "author": "Ossif",
    "version": (1, 0),
    "blender": (2, 80, 0),
    "location": "View3D > Sidebar > MBRA",
    "description": "Addon for converting bones to/from Mixamo Standart naming convention.",
    "warning": "",
    "wiki_url": "",
    "category": "Rigging"
}

class BoneAddon(bpy.types.Panel):
    """Creates a Panel in the Object properties window"""
    bl_label = "Mixamo bone renaming"
    bl_idname = "OBJECT_PT_mixamo_standart"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'MBRA'

    def draw(self, context):
        layout = self.layout

        row = layout.row()
        row.operator("object.convert_from_mixamo_standart", text="Rename From Mixamo Standart")
        row = layout.row()
        row.operator("object.convert_to_mixamo_standart", text="Rename To Mixamo Standart")


class ConvertToMixamoStandartOperator(bpy.types.Operator):
    """Rename bones from Blender Standart to Mixamo standart ("mixamorig:Left" or "mixamorig:Right" prefixes)"""
    bl_idname = "object.convert_to_mixamo_standart"
    bl_label = "Convert to Mixamo Standart"

    def execute(self, context):
        if context.active_object and context.active_object.type == 'ARMATURE':
            armature = context.active_object
            for bone in armature.pose.bones:
                if 'mixamorig:' in bone.name:
                    if bone.name[-2:] == ".L":
                        new_name = bone.name.replace('mixamorig:', 'mixamorig:Left')
                        new_name = new_name[:-2]
                        bone.name = new_name
                    elif bone.name[-2:] == ".R":
                        new_name = bone.name.replace('mixamorig:', 'mixamorig:Right')
                        new_name = new_name[:-2]
                        bone.name = new_name
        else:
            self.report({'WARNING'}, "No armature selected")
        return {'FINISHED'}
    

class ConvertFromMixamoStandartOperator(bpy.types.Operator):
    """Rename bones from Mixamo Standart to Blender standart (".L" or ".R" suffixes)"""
    bl_idname = "object.convert_from_mixamo_standart"
    bl_label = "Convert from Mixamo Standart"

    def execute(self, context):
        if context.active_object and context.active_object.type == 'ARMATURE':
            armature = context.active_object
            for bone in armature.pose.bones:
                if 'mixamorig:' in bone.name:
                    if 'Left' in bone.name:
                        new_name = bone.name.replace('Left', '') + '.L'
                        bone.name = new_name
                    elif 'Right' in bone.name:
                        new_name = bone.name.replace('Right', '') + '.R'
                        bone.name = new_name
        else:
            self.report({'WARNING'}, "No armature selected")
        return {'FINISHED'}


def register():
    bpy.utils.register_class(BoneAddon)
    bpy.utils.register_class(ConvertToMixamoStandartOperator)
    bpy.utils.register_class(ConvertFromMixamoStandartOperator)


def unregister():
    bpy.utils.unregister_class(BoneAddon)
    bpy.utils.unregister_class(ConvertToMixamoStandartOperator)
    bpy.utils.unregister_class(ConvertFromMixamoStandartOperator)


if __name__ == "__main__":
    register()
