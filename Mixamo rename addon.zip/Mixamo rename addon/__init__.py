import bpy
import BoneAddon

bl_info = {
    "name": "Mixamo Bone Renamer Addon",
    "author": "Ossif",
    "version": (1, 0),
    "blender": (2, 80, 0),
    "location": "View3D > Sidebar > MBRA",
    "description": "Addon for converting bones to/from Mixamo Standart naming convention.",
    "warning": "",
    "wiki_url": "",
    "category": "Rigging"
}

def register():
    BoneAddon.register()

def unregister():
    BoneAddon.unregister()

if __name__ == "__main__":
    register()
